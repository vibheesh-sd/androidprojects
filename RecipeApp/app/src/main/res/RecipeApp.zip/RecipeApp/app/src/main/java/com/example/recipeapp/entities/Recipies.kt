package com.example.recipeapp.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "Recipies")
data class Recipies(
    @PrimaryKey(autoGenerate = true)
    var id:Int
):Serializable
